mylist = ["aaditya",214,345,56,568,"not","abcd"]

newlist = []

for i in mylist:
    if(type(i)==int):
        print(i)
        newlist.append(i)

print("Sum is : ",sum(newlist))
