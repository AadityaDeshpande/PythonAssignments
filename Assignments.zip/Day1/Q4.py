mystr = input("Enter a string : ")

if(mystr == "psl" or mystr == "PSL"):
    print("Valid Password")

else:
    print("Not a valid Password")
