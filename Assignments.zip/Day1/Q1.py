mystr = input("Enter a string to check its pallindrome: ");

if(mystr==mystr[::-1]):
    print("Its a Pallindrome")
else:
    print("Its not a Pallindrome")
