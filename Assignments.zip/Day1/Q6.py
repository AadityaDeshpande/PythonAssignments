mylist = []

try:
    count = int( input("Enter Count: ") )

    for i in range(count):
        no = int( input("Enter Number {} ".format((i+1)) ) )
        mylist.append(no)
        
    

except ValueError:
    print("Exception Caught: Enter all Int")
    #print(mylist)
    
mylist.sort()
print(mylist)
