no1 = int( input("Enter a number 1: ") )

no2 = int( input("Enter a number 2: ") )

print("Addition is : ",no1+no2)

print("Subtraction is : ",no1-no2)
