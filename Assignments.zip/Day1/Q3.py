mystr = input("Enter a string : ")

if(mystr.isupper()):
    print("String is All in Capital letters")

if(mystr.islower()):
    print("All Strings in Lower case")
    
