
def ReadFile(file_name):
    try:
        myDict = dict()
        
        myfile=open(file_name)

        while(True):
            line = myfile.readline()

            if(line == ""):
                break

            line = line.rstrip()

            line = line.split(',')

            if line[-1] not in myDict.keys():
                #myDict[line[-1]] = [line[0],]
                myDict[line[-1]] = {line[0]:[line[2],],}

            else:
                myDict[line[-1]].update({line[0]:[line[2],],})

        keys = list(myDict.keys())

        keys.sort()

        #print(myDict)
        
        for i in keys:
            print("{} {}".format(i,myDict[i]))


    except IOError as e:
        print("Caught an exception ",e)

    finally:
        #print("Inside Finally")
        myfile.close()


if __name__=='__main__':
    ReadFile("country.txt")
