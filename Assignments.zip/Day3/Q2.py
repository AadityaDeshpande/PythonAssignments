'''
Conside this file as caller File
'''
from Q1 import ReadFile

if __name__=='__main__':
    ReadFile("country.txt")
    
