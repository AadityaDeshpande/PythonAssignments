emp ={'1a':30000,'2a':40000}

print(emp)

while(True):
    str1 = input("Enter emp ID:salaray in a single line: ")
    if (str1==""):
        break
    str1.rstrip()
    token = str1.split(':')
    emp[token[0]]=int(token[1])
    print(emp)

mykeys = list(emp.keys())

mykeys.sort()

#print (mykeys)
for i in mykeys:
    print("key is {} and value is {}".format(i,emp[i]))

for i in mykeys:
    emp[i]+=5000
    print("key is {} and value is {}".format(i,emp[i]))

print(emp)
