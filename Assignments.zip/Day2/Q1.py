uList = ['Aaaa', 'bb', 'cccccccc', 'zzzzzzzzzzzz']


uList.sort(key=len)

print(uList)
