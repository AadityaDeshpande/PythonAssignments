Emp = {}  #in memeory data structure storage
FH =open("empdata.txt")
for line in FH:
	Line = line.rstrip()
	L1 = Line.split(':')   #[1a, ABC, 25, 25000]
	Emp[L1[0]]=L1[1:3]
	Emp[L1[0]].append(int(L1[3]))
print(Emp)

#sumval=[]

sumval=list(Emp.values())

print(sumval)

ssum = [ (i[2]) for i in sumval]

print("sum is : ",sum(ssum))
