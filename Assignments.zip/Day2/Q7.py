myDict = {}


file = open("country.txt")

while(True):
    line = file.readline()
    if(line == ""):
        break

    line = line.rstrip()

    line = line.split(',')

    if line[-1] not in myDict.keys() :
        myDict[line[-1]] = [line[0],]

    else:
        myDict[line[-1]].append(line[0])
    
    #print(line)

file.close()

keys = list(myDict.keys())

keys.sort()

for i in keys:
    print("{} {}".format(i,myDict[i]))
