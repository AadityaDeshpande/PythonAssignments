myList = ["asdas","sedgsda","tysadg","vsdhr","dwdhe"]

ans = [ i.title()  for i in myList ]

print(ans)
