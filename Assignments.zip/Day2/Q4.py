def add(no1,no2):
    return (no1+no2)

print(add(no2 =4,no1=3))
