
myDict = {}


file = open("country.txt")

while(True):
    line = file.readline()
    if(line == ""):
        break

    line = line.rstrip()

    line = line.split(',')

    if(line[-1] in myDict.keys()):
        myDict[line[-1]]+=1

    else:
        myDict[line[-1]]=1


file.close()

#print(myDict)

#for i,j in myDict.items():
#    print("{} {}".format(i,j))

keys = list(myDict.keys())

keys.sort()

for i in keys:
    print("{} {}".format(i,myDict[i]))
